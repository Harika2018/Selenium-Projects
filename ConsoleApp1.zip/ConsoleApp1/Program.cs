﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.IE;
using OpenQA.Selenium;
using System.IO;
using System.Reflection;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System.Threading;


namespace Harika_test
{
    class Program
    {
        static void Main(string[] args)
        {
            string testScriptStartupPath = Assembly.GetExecutingAssembly().Location;
            string path = Path.GetDirectoryName(testScriptStartupPath);
            
        var chromeOptions = new ChromeOptions();
            IWebDriver iedriver = new ChromeDriver(path);
            iedriver.Navigate().GoToUrl("https://nationwide.co.uk");
            iedriver.Manage().Window.Maximize();
            IWebElement mortgage = iedriver.FindElement(By.Id("MortgagesNavItem"));
            IWebElement loans = iedriver.FindElement(By.Id("LoansNavItem"));
            Actions actions = new Actions(iedriver);            
            iedriver.FindElement(By.Id("searchInput")).Click();
            Thread.Sleep(1000);
            actions.MoveToElement(mortgage).Build().Perform();
            actions.MoveToElement(loans).Build().Perform();
            actions.MoveToElement(mortgage).Build().Perform();
               System.Threading.Thread.Sleep(2000);
               iedriver.FindElement(By.CssSelector("[href*='/products/mortgages/our-mortgage-rates']")).Click();
            System.Threading.Thread.Sleep(2000);
            iedriver.FindElement(By.Id("selectorItemHaveNationwideMortgage1")).Click();
            iedriver.FindElement(By.Id("selectorItemNationwideMortgageTypeNo2")).Click();
            iedriver.FindElement(By.Id("SearchPropertyValue")).SendKeys("300000");
            iedriver.FindElement(By.Id("SearchMortgageAmount")).SendKeys("150000");
            iedriver.FindElement(By.Id("SearchMortgageTerm")).SendKeys("30");
            iedriver.FindElement(By.Id("myButton")).Click();
            System.Threading.Thread.Sleep(1000);
            IList<IWebElement> checkboxes = iedriver.FindElements(By.XPath("//div[@role='checkbox']"));
            foreach (IWebElement checkbox in checkboxes)
            {
                Thread.Sleep(2000);
                if (checkbox.Text == "Fixed rate")                
                    checkbox.Click();                                   
                else if (checkbox.Text == "5 years")                
                    checkbox.Click();                                    
                else if (checkbox.Text == "With fee")
                {
                    checkbox.Click();
                    break;
                }
            }
            Thread.Sleep(1000);
                IWebElement tableData = iedriver.FindElement(By.Id("NewMortgageRateTables"));
            ICollection<IWebElement> tableRows = tableData.FindElements(By.TagName("tr"));
            foreach (IWebElement row in tableRows)
            {
                iedriver.FindElement(By.XPath("//th/a/span[@class='triggerText']")).Click();
                iedriver.FindElement(By.XPath("//div[@class='applyButton doNotPrint']")).Click();
                break;
            }
            iedriver.SwitchTo().Window(iedriver.CurrentWindowHandle);
            IWebElement newpage = iedriver.FindElement(By.XPath("//h1[@class='blue boldText headingSize02  center ']"));
            if (newpage.Text == "Start your Remortgage application")
                Console.WriteLine("Mortgage recorded successfully");
            iedriver.Quit();
        }
    }
}
